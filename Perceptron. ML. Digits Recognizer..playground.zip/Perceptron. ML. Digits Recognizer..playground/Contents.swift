import UIKit
//
//https://neuralnet.info/chapter/персептроны/
//

var digitsImage = UIImage(imageLiteralResourceName: "4-training_set.png")
//цифры 0..9
var num0 = [1,1,1,1,0,1,1,0,1,1,0,1,1,1,1]
var num1 = [0,0,1,0,0,1,0,0,1,0,0,1,0,0,1]
var num2 = [1,1,1,0,0,1,1,1,1,1,0,0,1,1,1]
var num3 = [1,1,1,0,0,1,1,1,1,0,0,1,1,1,1]
var num4 = [1,0,1,1,0,1,1,1,1,0,0,1,0,0,1]
var num5 = [1,1,1,1,0,0,1,1,1,0,0,1,1,1,1]
var num6 = [1,1,1,1,0,0,1,1,1,1,0,1,1,1,1]
var num7 = [1,1,1,0,0,1,0,0,1,0,0,1,0,0,1]
var num8 = [1,1,1,1,0,1,1,1,1,1,0,1,1,1,1]
var num9 = [1,1,1,1,0,1,1,1,1,0,0,1,1,1,1]
var nums = [num0, num1, num2, num3, num4, num5, num6, num7, num8, num9]

//искаженные цифры 5
var distoredFivesImage = UIImage(imageLiteralResourceName: "4-training_set_complete.png")
var num51 = [1,1,1,1,0,0,1,1,1,0,0,0,1,1,1]
var num52 = [1,1,1,1,0,0,0,1,0,0,0,1,1,1,1]
var num53 = [1,1,1,1,0,0,0,1,1,0,0,1,1,1,1]
var num54 = [1,1,0,1,0,0,1,1,1,0,0,1,1,1,1]
var num55 = [1,1,0,1,0,0,1,1,1,0,0,1,0,1,1]
var num56 = [1,1,1,1,0,0,1,0,1,0,0,1,1,1,1]

//веса
var weights: [Int] = []

//обнуление весов
for _ in 1...15{
    weights.append(0)
}

//порог
var step = 7

//основная проверка цифры
func checkFive(five:[Int])->Bool{
    var sum = 0
    for i in 0...five.count-1{
        sum = sum + five[i] * weights[i]
    }
    
    if sum >= step {
        return true
    } else{
        return false
    }
    
}

//если распознала 5 там, где ее нет (уменьшаем)
func decrease(five:[Int]){
    for i in 0...five.count-1{
        if five[i] == 1 {
            weights[i] -= 1
        }
    }
}
// если не распознала 5, там где 5 (увеличиваем)
func increase(five:[Int]){
    for i in 0...five.count-1{
        if five[i] == 1 {
            weights[i] += 1
        }
    }
}

//обучение
for _ in 0...20000{
    let randomDigit = Int.random(in: 0...9)
    
    if randomDigit == 5{
        if !(checkFive(five: nums[randomDigit])){
            increase(five: num5)
        }
    }
    
    if randomDigit != 5 {
        if checkFive(five: nums[randomDigit]){
            decrease(five: nums[randomDigit])
        }
    }
    
}


print(weights)

print("0 это 5? \(checkFive(five: num0))")
print("1 это 5? \(checkFive(five: num1))")
print("2 это 5? \(checkFive(five: num2))")
print("3 это 5? \(checkFive(five: num3))")
print("4 это 5? \(checkFive(five: num4))")
print("5 это 5? \(checkFive(five: num5))")
print("6 это 5? \(checkFive(five: num6))")
print("7 это 5? \(checkFive(five: num7))")
print("8 это 5? \(checkFive(five: num8))")
print("9 это 5? \(checkFive(five: num9))")

//искаженные варианты цифры 5
print("5(1) это 5? \(checkFive(five: num51))")
print("5(2) это 5? \(checkFive(five: num52))")
print("5(3) это 5? \(checkFive(five: num53))")
print("5(4) это 5? \(checkFive(five: num54))")
print("5(5) это 5? \(checkFive(five: num55))")
print("5(6) это 5? \(checkFive(five: num56))")
